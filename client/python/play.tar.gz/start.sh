#!/bin/bash
python3 play.py
